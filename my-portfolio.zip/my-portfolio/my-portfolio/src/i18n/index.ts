import { createI18n } from 'vue-i18n';


const messages = {
  en: {
    about: 'About Me',
    projects: 'Projects',
    skills: 'Skills',
    experience: 'Experience',
    contact: 'Contact',
  },
  es: {
    about: 'Sobre mí',
    projects: 'Proyectos',
    skills: 'Habilidades',
    experience: 'Experiencia',
    contact: 'Contacto',
  },
};

const i18n = createI18n({
  locale: 'en',
  fallbackLocale: 'es',
  messages,
});

export default i18n;
