<template>
  <div id="app" class="d-flex flex-column min-vh-100">
    <header class="bg-primary text-white py-3">
      <div class="container d-flex justify-content-between align-items-center">
        <h1 class="h3 mb-0">Mi Portafolio</h1>
        <nav>
          <ul class="nav">
            <li class="nav-item"><router-link class="nav-link text-white" to="/">Inicio</router-link></li>
            <li class="nav-item"><router-link class="nav-link text-white" to="/skills">Habilidades</router-link></li>
            <li class="nav-item"><router-link class="nav-link text-white" to="/projects">Proyectos</router-link></li>
            <li class="nav-item"><router-link class="nav-link text-white" to="/experience">Experiencia</router-link></li>
            <li class="nav-item"><router-link class="nav-link text-white" to="/about">Sobre Mí</router-link></li>
            <li class="nav-item"><router-link class="nav-link text-white" to="/contact">Contacto</router-link></li>
          </ul>
        </nav>
      </div>
    </header>
    <main class="flex-grow-1 py-4">
      <div class="container">
        <router-view />
      </div>
    </main>
    <footer class="bg-light text-center py-3 border-top">
      <p class="mb-0">&copy; 2024 Rafael Martín Mayor - Todos los derechos reservados.</p>
    </footer>
  </div>
</template>

<script lang="ts">
export default {
  name: "App",
};
</script>

<style>

#app {
  font-family: 'Arial', sans-serif;
}

header h1 {
  font-weight: bold;
}

footer p {
  font-size: 0.9rem;
  color: #666;
}

.nav-link:hover {
  text-decoration: underline;
}
</style>
