import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
    apiKey: "AIzaSyBP8tGGgvR4v_Z_060a9jGQrRexlJ470FQ",
    authDomain: "contacto-portafolio-a9481.firebaseapp.com",
    projectId: "contacto-portafolio-a9481",
    storageBucket: "contacto-portafolio-a9481.firebasestorage.app",
    messagingSenderId: "99480624223",
    appId: "1:99480624223:web:a4dd326e4d429e6cbb8fea"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };
