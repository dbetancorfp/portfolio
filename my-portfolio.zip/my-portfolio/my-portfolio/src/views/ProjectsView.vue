<template>
  <section class="projects">
    <h1 class="text-primary mb-4">Proyectos</h1>
    <div class="row">
      <div class="col-md-6 mb-4" v-for="project in projects" :key="project.id">
        <div class="card h-100 shadow-sm">
          <img :src="project.image" class="card-img-top" alt="Imagen del proyecto" />
          <div class="card-body">
            <h5 class="card-title">{{ project.title }}</h5>
            <p class="card-text">{{ project.description }}</p>
          </div>
          <div class="card-footer bg-white text-center">
            <a :href="project.link" target="_blank" class="btn btn-primary">Ver proyecto</a>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
export default {
  name: "ProjectsView",
  data() {
    return {
      projects: [
        {
          id: 1,
          title: "Proyecto de ejemplo 1",
          description: "Descripción del Proyecto de ejemplo 1.",
          link: "https://github.com/usuario/proyecto-ejemplo-1",
          image: "https://via.placeholder.com/400x200?text=Proyecto+de+ejemplo+1",
        },
        {
          id: 2,
          title: "Proyecto de ejemplo 2",
          description: "Descripción del Proyecto de ejemplo 2.",
          link: "https://github.com/usuario/proyecto-ejemplo-2",
          image: "https://via.placeholder.com/400x200?text=Proyecto+de+ejemplo+2",
        },
        {
          id: 3,
          title: "Proyecto de ejemplo 3",
          description: "Descripción del Proyecto de ejemplo 3.",
          link: "https://github.com/usuario/proyecto-ejemplo-3",
          image: "https://via.placeholder.com/400x200?text=Proyecto+de+ejemplo+3",
        },
      ],
    };
  },
};
</script>

<style scoped>
.card {
  border: 1px solid #ddd;
  transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}

.card:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.card-footer {
  border-top: none;
}
</style>
