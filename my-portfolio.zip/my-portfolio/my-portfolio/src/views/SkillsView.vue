<template>
  <section class="skills py-5">
    <div class="container">
      <h1 class="text-primary mb-5 text-center">Habilidades</h1>
      <div class="row">
        <div class="col-md-4 mb-4" v-for="skill in skills" :key="skill.name">
          <div class="card shadow-sm">
            <div class="card-body text-center">
              <img
                :src="skill.logo"
                :alt="skill.name"
                class="img-fluid mb-3"
                style="max-width: 80px;"
              />
              <h5 class="card-title text-secondary">{{ skill.name }}</h5>
              <p class="card-text">{{ skill.description }}</p>
              <div class="progress" style="height: 20px;">
                <div
                  class="progress-bar"
                  :style="{ width: skill.level + '%', backgroundColor: skill.color }"
                  role="progressbar"
                  :aria-valuenow="skill.level"
                  aria-valuemin="0"
                  aria-valuemax="100"
                >
                  {{ skill.level }}%
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
export default {
  name: "SkillsView",
  data() {
    return {
      skills: [
        {
          name: "JavaScript",
          logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg",
          description: "Usado en proyectos frontend y backend con Node.js.",
          level: 90,
          color: "#f7df1e",
        },
        {
          name: "TypeScript",
          logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg",
          description: "Trabajé con TypeScript para estructurar aplicaciones Vue.js.",
          level: 75,
          color: "#007acc",
        },
        {
          name: "HTML & CSS",
          logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg",
          description: "Desarrollo de interfaces web responsivas y accesibles.",
          level: 95,
          color: "#e34c26",
        },
        {
          name: "Vue.js",
          logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vuejs/vuejs-original.svg",
          description: "Creación de interfaces web con Vue Router y Pinia.",
          level: 80,
          color: "#42b883",
        },
        {
          name: "Firebase",
          logo: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/firebase/firebase-plain.svg",
          description: "Integración de backend para autenticación y Firestore.",
          level: 70,
          color: "#ffca28",
        },
      ],
    };
  },
};
</script>

<style scoped>

.card {
  border-radius: 10px;
}

.card img {
  height: auto;
  width: 100%;
  max-width: 80px;
}

.card-title {
  font-size: 1.25rem;
}

.progress-bar {
  font-weight: bold;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
}
</style>
