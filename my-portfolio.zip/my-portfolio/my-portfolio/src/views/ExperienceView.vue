<template>
  <section class="experience py-5">
    <div class="container">
      <h1 class="text-primary mb-5 text-center">Experiencia</h1>
      <div class="timeline">
        <div class="timeline-item" v-for="experience in experiences" :key="experience.id">
          <div class="timeline-icon">
            <i class="bi bi-briefcase-fill"></i>
          </div>
          <div class="timeline-content">
            <h5 class="mb-1">{{ experience.role }}</h5>
            <p class="text-muted mb-2">
              {{ experience.company }} - {{ experience.year }}
            </p>
            <p>{{ experience.description }}</p>
          </div>
        </div>
      </div>
      <div class="text-center mt-5">
        <button @click="downloadCV" class="btn btn-primary btn-lg">
          Descargar CV en PDF
        </button>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
export default {
  name: "ExperienceView",
  data() {
    return {
      experiences: [
        {
          id: 1,
          role: "Desarrollador Junior",
          company: "Tech Solutions",
          year: "2026",
          description: "Participé en el desarrollo de una plataforma de gestión utilizando Vue.js y Node.js.",
        },
        {
          id: 2,
          role: "Prácticas de Empresa",
          company: "InnovApp",
          year: "2025",
          description: "Desarrollé y mejoré funcionalidades para aplicaciones móviles en un entorno ágil.",
        },
        {
          id: 3,
          role: "Estudiante de DAW",
          company: "IES Puerto de la Cruz",
          year: "2024",
          description: "Realicé proyectos académicos enfocados en desarrollo web con HTML, CSS y JavaScript.",
        },
      ],
    };
  },
  methods: {
    downloadCV() {
      const link = document.createElement("a");
      link.href = "/cv/rafael_martin_mayor_cv.pdf";
      link.download = "Rafael_Martin_Mayor_CV.pdf";
      link.click();
    },
  },
};
</script>

<style scoped>
.timeline {
  position: relative;
  padding: 2rem 0;
  margin-top: 2rem;
  border-left: 3px solid #4caf50;
}

.timeline-item {
  position: relative;
  margin-bottom: 2rem;
  padding-left: 2rem;
}

.timeline-icon {
  position: absolute;
  left: -1.2rem;
  top: 0;
  background: #4caf50;
  color: white;
  border-radius: 50%;
  width: 1.5rem;
  height: 1.5rem;
  display: flex;
  justify-content: center;
  align-items: center;
}

.timeline-content {
  background: #f8f9fa;
  border: 1px solid #ddd;
  padding: 1rem;
  border-radius: 0.5rem;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.timeline-content h5 {
  font-weight: bold;
  color: #333;
}

.timeline-content p {
  margin: 0;
}

button {
  font-size: 1.2rem;
}
</style>
