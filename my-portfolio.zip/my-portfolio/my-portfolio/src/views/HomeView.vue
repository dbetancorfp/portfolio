<template>
  <section class="home">
    <div class="jumbotron bg-light text-center py-5">
      <div class="container">
        <h1 class="display-4">¡Hola, soy Rafael Martín Mayor!</h1>
        <p class="lead">
          Soy un desarrollador junior apasionado por crear soluciones innovadoras con tecnologías modernas.
        </p>
        <hr class="my-4" />
        <p>
          Explora mi portafolio para conocer mis proyectos, habilidades y experiencia.
        </p>
        <a class="btn btn-dark btn-lg" href="/projects" role="button">Ver Mis Proyectos</a>
      </div>
    </div>
    <div class="container text-center my-5">
      <h2 class="text-secondary mb-4">¿Qué encontrarás aquí?</h2>
      <div class="row">
        <div class="col-md-4 mb-4">
          <div class="card shadow-sm h-100">
            <div class="card-body">
              <h5 class="card-title">Habilidades</h5>
              <p class="card-text">Conoce mis principales habilidades en desarrollo frontend y backend.</p>
              <a href="/skills" class="btn btn-outline-primary">Descubrir</a>
            </div>
          </div>
        </div>
        <div class="col-md-4 mb-4">
          <div class="card shadow-sm h-100">
            <div class="card-body">
              <h5 class="card-title">Proyectos</h5>
              <p class="card-text">Explora algunos de los proyectos en los que he trabajado.</p>
              <a href="/projects" class="btn btn-outline-primary">Ver Proyectos</a>
            </div>
          </div>
        </div>
        <div class="col-md-4 mb-4">
          <div class="card shadow-sm h-100">
            <div class="card-body">
              <h5 class="card-title">Contacto</h5>
              <p class="card-text">Ponte en contacto conmigo para trabajar juntos o resolver tus dudas.</p>
              <a href="/contact" class="btn btn-outline-primary">Contactar</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
export default {
  name: "HomeView",
};
</script>

<style scoped>
.jumbotron {
  background: linear-gradient(135deg, #4caf50, #81c784);
  color: white;
  border-radius: 0.5rem;
}

.card {
  transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}

.card:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}
</style>
