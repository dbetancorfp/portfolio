<template>
  <section class="about py-5">
    <div class="container">
      <h1 class="text-primary mb-5 text-center">Sobre mí</h1>
      <div class="row align-items-center">
        <div class="col-md-4 text-center mb-4 mb-md-0">
          <img
            src="https://via.placeholder.com/200?text=Foto+de+Perfil"
            alt="Foto de perfil"
            class="img-fluid rounded-circle shadow"
          />
        </div>

        <div class="col-md-8">
          <h2 class="text-secondary">¡Hola, soy Rafael Martín Mayor!</h2>
          <p>
            Soy un desarrollador junior recién titulado en <strong>Desarrollo de Aplicaciones Web (DAW)</strong>,
            con una gran pasión por el aprendizaje continuo y el desarrollo de soluciones innovadoras.
          </p>
          <p>
            Durante mi formación, adquirí habilidades sólidas en tecnologías como
            <strong>Vue.js</strong>, <strong>Node.js</strong>, <strong>JavaScript</strong> y
            <strong>TypeScript</strong>. Me encanta trabajar en equipo y enfrentar nuevos retos tecnológicos.
          </p>
          <p>
            Actualmente busco oportunidades para crecer como desarrollador y contribuir a proyectos
            emocionantes que hagan la diferencia.
          </p>
          <a href="mailto:rmarmay2004@gmail.com" class="btn btn-primary mt-3">
            Contactarme
          </a>
        </div>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
export default {
  name: "AboutView",
};
</script>

<style scoped>

img {
  width: 200px;
  height: 200px;
  object-fit: cover;
}


.btn-primary {
  background-color: #4caf50;
  border-color: #4caf50;
}

.btn-primary:hover {
  background-color: #45a049;
}
</style>
