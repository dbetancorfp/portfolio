<template>
  <section class="contact py-5">
    <div class="container">
      <h1 class="text-primary mb-5 text-center">Contacto</h1>
      <div class="row">
        <div class="col-md-6 mb-4">
          <h2 class="text-secondary">¡Envíame un mensaje!</h2>
          <p>Estoy disponible para proyectos y colaboraciones.</p>
          <p>
            <strong>Email:</strong>
            <a href="mailto:rmarmay2004@gmail.com" class="text-primary">rmarmay2004@gmail.com</a>
          </p>
        </div>
        <div class="col-md-6">
          <form @submit.prevent="submitForm">
            <div class="mb-3">
              <label for="name" class="form-label">Nombre</label>
              <input
                type="text"
                id="name"
                class="form-control"
                v-model="formData.name"
                placeholder="Tu nombre"
                required
              />
            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Correo Electrónico</label>
              <input
                type="email"
                id="email"
                class="form-control"
                v-model="formData.email"
                placeholder="tucorreo@example.com"
                required
              />
            </div>
            <div class="mb-3">
              <label for="message" class="form-label">Mensaje</label>
              <textarea
                id="message"
                class="form-control"
                v-model="formData.message"
                rows="5"
                placeholder="Escribe tu mensaje"
                required
              ></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button>
          </form>
          <p v-if="successMessage" class="text-success mt-3">{{ successMessage }}</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
import { ref } from "vue";
import { db } from "@/firebase";
import { collection, addDoc } from "firebase/firestore";

export default {
  name: "ContactView",
  setup() {
    const formData = ref({
      name: "",
      email: "",
      message: "",
    });
    const successMessage = ref("");

    const submitForm = async () => {
      try {
        const messagesRef = collection(db, "messages");
        await addDoc(messagesRef, {
          name: formData.value.name,
          email: formData.value.email,
          message: formData.value.message,
          timestamp: new Date(),
        });
        successMessage.value = "¡Gracias! Tu mensaje ha sido enviado.";
        formData.value = { name: "", email: "", message: "" };
      } catch (error) {
        console.error("Error al enviar el mensaje:", error);
      }
    };

    return {
      formData,
      successMessage,
      submitForm,
    };
  },
};
</script>

<style scoped>
a {
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}

button {
  background-color: #4caf50;
  border-color: #4caf50;
}

button:hover {
  background-color: #45a049;
}

.text-success {
  font-weight: bold;
}
</style>
