<template>
  <footer class="bg-dark text-white text-center py-2">
    <p>© 2024 Portfolio - All rights reserved</p>
  </footer>
</template>

<script lang="ts">
export default {
  name: 'Footer',
};
</script>

<style scoped>
footer {
  background-color: #333;
  padding: 1rem 0; 
  margin-top: 0; 
}

footer p {
  font-size: 1rem;
  margin: 0;
  color: #f8f9fa;
}
main[data-v-7a7a37b1] {
    flex-grow: 0;
    background-color: #333;
    padding-bottom: 0;
}
</style>
